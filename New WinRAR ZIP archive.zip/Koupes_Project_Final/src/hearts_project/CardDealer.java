

package hearts_project;


public interface CardDealer {
    
    void shuffleDeck();
    void dealToPlayers(HeartPlayer player1,HeartPlayer player2);
    String decideWinner(HeartPlayer player1, HeartPlayer player2, int round);
    
    
    
    
}
