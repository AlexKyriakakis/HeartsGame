
package hearts_project;


abstract public class Human {
    
    public String Fname;
    public String  Lname;
    public int age;
    
    Human(){
    Fname="";
    Lname="";
    age=0;
   }
    
    
    abstract String IntroduceYourSelf();
    
}
