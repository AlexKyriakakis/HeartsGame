
package hearts_project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


 public  class SQLConnection {

    
    static Connection conn = null;

     public static Connection ConnectDB() {
        try {
            Class.forName("com.mysql.jdbc.Driver");

            String dbUser = "root";
            String dbPass = "";

            String dbHost = "localhost";
            String dbPort = "3306";
            String dbName = "koupes2";
            String url = "jdbc:mysql://" + dbHost + ":" + dbPort + "/" + dbName;

            Connection conn = DriverManager.getConnection(url, dbUser, dbPass);

            System.out.println("Komple");
            return conn;

        } catch (ClassNotFoundException e) {
            System.out.println("Driver Not Found");
            e.printStackTrace(System.out);
            return null;
        } catch (SQLException ex) {
            System.out.println("ERROR : Connection not established");
            ex.printStackTrace(System.out);
            return null;
        }

    }
}