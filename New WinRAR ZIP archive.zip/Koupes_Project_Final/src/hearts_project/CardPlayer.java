

package hearts_project;


public interface CardPlayer {
    void showHand();
    
}
