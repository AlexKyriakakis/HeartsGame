package hearts_project;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Register {

    JTextField fnametext = null;
    JTextField lastnametext = null;
    JTextField agetext = null;
    JTextField usernametext = null;
    Connection conn = null;
    Statement stmt = null;
    int guardP1 = 0, guardP2 = 0, guardDealer = 0;

    public Register(final Heartsdealer dealer, final HeartPlayer P1, final HeartPlayer P2) {

       // conn = SQLConnection.ConnectDB();

        JFrame jf = new JFrame();
        jf.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        jf.setSize(450, 250);
        jf.setTitle("Registration");
        GridLayout grid = new GridLayout(4, 2);
        GridLayout regBtnsGrid = new GridLayout(1, 3);
        GridLayout playGameGrid = new GridLayout(1, 1);

        JPanel pan = new JPanel();
        JPanel pan2 = new JPanel();
        JPanel pan3 = new JPanel();
        pan.setLayout(grid);
        pan2.setLayout(regBtnsGrid);
        pan3.setLayout(playGameGrid);

        jf.add(pan, BorderLayout.NORTH);
        jf.add(pan2, BorderLayout.CENTER);
        jf.add(pan3, BorderLayout.SOUTH);

        Font font1 = new Font("SansSerif", Font.BOLD, 20); //fonts for JTextfield

        JLabel label1 = new JLabel();
        label1.setText("   First Name");
        pan.add(label1);

        fnametext = new JTextField();
        pan.add(fnametext);
        fnametext.setFont(font1);

        JLabel label2 = new JLabel();
        label2.setText("   Last Name");
        pan.add(label2);

        lastnametext = new JTextField();
        pan.add(lastnametext);
        lastnametext.setFont(font1);

        JLabel label3 = new JLabel();
        label3.setText("   Age");
        pan.add(label3);

        agetext = new JTextField();
        pan.add(agetext);
        agetext.setFont(font1);

        JLabel label4 = new JLabel();
        label4.setText("   Username");
        pan.add(label4);

        usernametext = new JTextField();
        pan.add(usernametext);
        usernametext.setFont(font1);

        JButton p1Reg = new JButton();
        pan2.add(p1Reg);
        p1Reg.setText("   Register Player 1");

        JButton p2Reg = new JButton();
        pan2.add(p2Reg);
        p2Reg.setText("   Register Player 2");

        JButton dReg = new JButton();
        pan2.add(dReg);
        dReg.setText("   Register Dealer");

        JButton playBtn = new JButton();
        pan3.add(playBtn);
        playBtn.setText("Play Game");

        jf.setVisible(true);

        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Calendar cal = Calendar.getInstance();
        final String date = dateFormat.format(cal.getTime());

        p1Reg.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {

                if (guardP1 == 0) {
                    if (agetext.getText().equals("") || fnametext.getText().equals("") || lastnametext.getText().equals("") || usernametext.getText().equals("")) {
                        JOptionPane.showMessageDialog(null, "Fill all empty fields");
                    } else {

                        guardP1 = 1;
                        P1.age = Integer.parseInt(agetext.getText());
                        P1.Fname = fnametext.getText();
                        P1.Lname = lastnametext.getText();
                        P1.username = usernametext.getText();
                        agetext.setText("");
                        fnametext.setText("");
                        lastnametext.setText("");
                        usernametext.setText("");
/*
                        try {
                            stmt = conn.createStatement();
                            int sql = stmt.executeUpdate("INSERT INTO PLAY VALUES('" + P1.Fname + "','" + P1.Lname + "','" + P1.age + "','" + P1.username + "','" + date + "','" + "Player 1" + "')");
                            JOptionPane.showMessageDialog(null, "Player 1 registered succesfully");
                        } catch (SQLException ex) {
                            JOptionPane.showMessageDialog(null, "Fill everything correctly");
                        }
*/
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "This player is already registered");
                }

            }
        });

        p2Reg.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {

                if (guardP2 == 0) {

                    if (agetext.getText().equals("") || fnametext.getText().equals("") || lastnametext.getText().equals("") || usernametext.getText().equals("")) {
                        JOptionPane.showMessageDialog(null, "Fill all empty fields");
                    } else {

                        guardP2 = 1;
                        P2.age = Integer.parseInt(agetext.getText());
                        P2.Fname = fnametext.getText();
                        P2.Lname = lastnametext.getText();
                        P2.username = usernametext.getText();
                        agetext.setText("");
                        fnametext.setText("");
                        lastnametext.setText("");
                        usernametext.setText("");

 /*                       try {
                            stmt = conn.createStatement();
                            int sql = stmt.executeUpdate("INSERT INTO PLAY VALUES('" + P2.Fname + "','" + P2.Lname + "','" + P2.age + "','" + P2.username + "','" + date + "','" + "Player 2" + "')");
                            JOptionPane.showMessageDialog(null, "Player 2 registered succesfully");
                        } catch (SQLException ex) {
                            JOptionPane.showMessageDialog(null, "Fill everything correctly");
                        }
*/
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "This player is already registered");
                }

            }
        });

        dReg.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {

                if (guardDealer == 0) {

                    if (agetext.getText().equals("") || fnametext.getText().equals("") || lastnametext.getText().equals("")) {
                        JOptionPane.showMessageDialog(null, "Fill all empty fields except username");
                    } else {

                        guardDealer = 1;
                        dealer.age = Integer.parseInt(agetext.getText());
                        dealer.Fname = fnametext.getText();
                        dealer.Lname = lastnametext.getText();
                        agetext.setText("");
                        fnametext.setText("");
                        lastnametext.setText("");
                        usernametext.setText("");

  /*                      try {
                            stmt = conn.createStatement();
                            int sql = stmt.executeUpdate("INSERT INTO PLAY VALUES('" + dealer.Fname + "','" + dealer.Lname + "','" + dealer.age + "','" + " " + "','" + date + "','" + "Dealer" + "')");
                            JOptionPane.showMessageDialog(null, "Dealer registered succesfully");
                        } catch (SQLException ex) {
                            JOptionPane.showMessageDialog(null, "Fill everything correctly");
                        }
    */                }
                } else {
                    JOptionPane.showMessageDialog(null, "The dealer is already registered");
                }

            }
        });

        playBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {

                if (guardP1 == 1 && guardP2 == 1 && guardDealer == 1) {
                    MainGui gui = new MainGui(dealer, P1, P2);

                } else {
                    JOptionPane.showMessageDialog(null, "Not everyone is registered");
                }

            }
        });

    }

}
