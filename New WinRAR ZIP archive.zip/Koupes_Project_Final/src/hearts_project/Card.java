
package hearts_project;

public class Card {

    private int type, value;
    private String[] cardType = {"#", "$", "%", "&"};
    private String[] cardValue = {"A", "K", "Q", "J", "10",
        "9", "8", "7", "6", "5", "4", "3", "2"};

    public Card(int types,int values) {
        type = types;
        value = values;

    }

    @Override
    public String toString() {
        String finalCard = cardType[type]+cardValue[value];
        return finalCard;
    }

}
