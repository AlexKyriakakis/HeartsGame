package hearts_project;

public class HeartPlayer extends Human implements CardPlayer {

    public HeartPlayer() {
        super();

    }
    Card[] hand = new Card[5];
    public String username;
    public int points=0;
    
    
    

    @Override
    public void showHand() {
        for (int i = 0; i < hand.length; i++) {
            System.out.print(hand[i] + " ");
        }
    }
    @Override
    public String IntroduceYourSelf() {

        String txtArea = ("Hello, my name is " + Fname + " " + Lname
                        + ". I am " + age + " years old. I am also known as " + username + ".");
        return txtArea;
    }

}
