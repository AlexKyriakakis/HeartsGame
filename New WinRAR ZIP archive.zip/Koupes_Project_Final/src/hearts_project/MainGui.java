package hearts_project;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class MainGui {

    int checkShowDeck = 0;
    int checkShowHandP1 = 0;
    int checkShowHandP2 = 0;
    int checkDecideWinner = 0;
    int dealToPlayers = 0;
    int introduceD = 0;
    int introduceP1 = 0;
    int introduceP2 = 0;
    int round = 1;

    public MainGui(final Heartsdealer dealer, final HeartPlayer P1, final HeartPlayer P2) {

        JFrame mainframe = new JFrame();
        mainframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel mainpanel = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();

        final JPanel p1Hand = new JPanel(new GridLayout(1, 6, 2, 2));
        final JPanel p2Hand = new JPanel(new GridLayout(1, 6, 2, 2));
        JPanel dealerP = new JPanel(new BorderLayout());
        JPanel dealerBtns = new JPanel(new GridLayout(2, 2));

        JPanel player1 = new JPanel(new BorderLayout());
        JPanel player1Btns = new JPanel(new GridLayout(1, 2));
        JPanel player1labels = new JPanel(new GridLayout(2, 1));

        JPanel player2 = new JPanel(new BorderLayout());
        JPanel player2Btns = new JPanel(new GridLayout(1, 2));
        JPanel player2labels = new JPanel(new GridLayout(2, 1));

        JPanel center = new JPanel(new GridLayout(2, 1));
        final JPanel deck = new JPanel(new GridLayout(9, 6));

        mainframe.add(mainpanel);

        final JTextArea mainta = new JTextArea();
        mainta.setPreferredSize(new Dimension(730, 100));
        mainta.setEditable(false);

        final JScrollPane deckScroll = new JScrollPane(deck);

        // to kano etsi giati allios to textarea kolaei mesa sto gridbaglayout
        final JScrollPane textAreaScroll = new JScrollPane(mainta);

        center.add(deckScroll);
        center.add(textAreaScroll);

        final JLabel dealerLabel = new JLabel("                                   Dealer");
        JButton dBtn1 = new JButton("Introduce");
        JButton dBtn2 = new JButton("Show Deck");
        JButton dBtn3 = new JButton("Deal Cards");
        JButton dBtn4 = new JButton("Decide Winner");
        dealerP.add(dealerLabel, BorderLayout.NORTH);
        dealerBtns.add(dBtn1);
        dealerBtns.add(dBtn2);
        dealerBtns.add(dBtn3);
        dealerBtns.add(dBtn4);
        dealerP.add(dealerBtns, BorderLayout.CENTER);

        final JLabel p1L = new JLabel("                                 Player1");
        final JLabel p1Hearts = new JLabel("Number of hearts : ");
        final JLabel p1Score = new JLabel("Total Score : 0");
        player1labels.add(p1Hearts);
        player1labels.add(p1Score);
        JButton p1Btn1 = new JButton("Introduce");
        JButton p1Btn2 = new JButton("Show Hand");

        String pathP1 = "empty.png";

        ImageIcon icon = new ImageIcon("Images/" + pathP1);
        JLabel p1PicLabel1 = new JLabel(icon);
        JLabel p1PicLabel2 = new JLabel(icon);
        JLabel p1PicLabel3 = new JLabel(icon);
        JLabel p1PicLabel4 = new JLabel(icon);
        JLabel p1PicLabel5 = new JLabel(icon);

        p1Hand.add(player1);

        p1Hand.add(p1PicLabel1);
        p1Hand.add(p1PicLabel2);
        p1Hand.add(p1PicLabel3);
        p1Hand.add(p1PicLabel4);
        p1Hand.add(p1PicLabel5);

        p1Hand.add(player1labels);

        player1Btns.add(p1Btn1);
        player1Btns.add(p1Btn2);
        player1.add(p1L, BorderLayout.NORTH);
        player1.add(player1Btns, BorderLayout.CENTER);

        final JLabel p2L = new JLabel("                                 Player2");
        final JLabel p2Hearts = new JLabel("Number of hearts : ");
        final JLabel p2Score = new JLabel("Total Score : ");
        player2labels.add(p2Hearts);
        player2labels.add(p2Score);
        JButton p2Btn1 = new JButton("Introduce");
        JButton p2Btn2 = new JButton("Show Hand");

        String pathP2 = "empty.png";

        ImageIcon iconP2 = new ImageIcon("Images/" + pathP2);
        JLabel p2PicLabel1 = new JLabel(iconP2);
        JLabel p2PicLabel2 = new JLabel(iconP2);
        JLabel p2PicLabel3 = new JLabel(iconP2);
        JLabel p2PicLabel4 = new JLabel(iconP2);
        JLabel p2PicLabel5 = new JLabel(iconP2);

        p2Hand.add(player2);

        p2Hand.add(p2PicLabel1);
        p2Hand.add(p2PicLabel2);
        p2Hand.add(p2PicLabel3);
        p2Hand.add(p2PicLabel4);
        p2Hand.add(p2PicLabel5);

        p2Hand.add(player2labels);

        player2Btns.add(p2Btn1);
        player2Btns.add(p2Btn2);
        player2.add(p2L, BorderLayout.NORTH);
        player2.add(player2Btns, BorderLayout.CENTER);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 1;
        c.weighty = 1;
        c.gridx = 0;
        c.gridy = 0;
        mainpanel.add(player1, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.fill = GridBagConstraints.VERTICAL;
        c.weightx = 1;
        c.weighty = 1;
        c.anchor = GridBagConstraints.NORTH;
        c.gridwidth = 2;
        c.gridx = 1;
        c.gridy = 0;
        mainpanel.add(p1Hand, c);//player1 cards

        c.fill = GridBagConstraints.HORIZONTAL;
        c.fill = GridBagConstraints.VERTICAL;
        c.weightx = 1;
        c.weighty = 1;
        c.gridx = 0;
        c.gridy = 1;
        mainpanel.add(dealerP, c);//dealer

        c.fill = GridBagConstraints.HORIZONTAL;
        c.fill = GridBagConstraints.VERTICAL;
        c.weightx = 1.0;
        c.weighty = 1.0;
        c.gridx = 1;
        c.gridy = 1;
        c.gridwidth = 2;
        mainpanel.add(center, c);//dealer

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 1;
        c.weighty = 1;
        c.anchor = GridBagConstraints.WEST;
        c.gridx = 0;
        c.gridy = 2;
        mainpanel.add(player2, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.fill = GridBagConstraints.VERTICAL;
        c.weightx = 1;
        c.weighty = 1;
        c.gridwidth = 2;
        c.anchor = GridBagConstraints.NORTH;
        c.gridx = 1;
        c.gridy = 2;
        mainpanel.add(p2Hand, c);//player2 cards

        mainframe.setSize(1000, 650);
        mainframe.setResizable(false);
        mainframe.setVisible(true);

        //player 1 introduce
        p1Btn1.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {

                if (introduceP1 == 0) {
                    introduceP1 = 1;
                    String txtArea = P1.IntroduceYourSelf();

                    p1L.setText("                              " + P1.username);

                    mainta.setText(txtArea);
                } else {
                    JOptionPane.showMessageDialog(null, "Player 1 already introduced himself");
                }
            }

        });
        //player 1 show hand
        p1Btn2.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {

                if (checkShowHandP1 == 0) {
                    if (dealToPlayers == 1) {

                        checkShowHandP1 = 1;

                        int score1 = 0;
                        for (int i = 0; i < 5; i++) {
                            if (P1.hand[i].toString().contains("#")) {
                                score1++;
                            }
                        }

                        mainta.setText(P1.username + " : I have " + score1 + " heart(s)!!");
                        p1Hearts.setText("Number of hearts : " + score1);

                        for (int i = 0; i < 5; i++) {

                            String pathShowP1 = P1.hand[i] + ".png";
                            ImageIcon showCardP1 = new ImageIcon("Images/" + pathShowP1);

                            JLabel p1ShowLabel = new JLabel(showCardP1);
                            p1Hand.remove(i);
                            p1Hand.add(p1ShowLabel, i);
                            p1Hand.repaint();
                            p1Hand.revalidate();
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Deal to players first!!");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "This player have already shown his hand");
                }

            }

        });

        //player 2 introduce
        p2Btn1.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                if (introduceP2 == 0) {
                    introduceP2 = 1;
                    String txtArea = P2.IntroduceYourSelf();

                    p2L.setText("                                    " + P2.username);

                    mainta.setText(txtArea);
                } else {
                    JOptionPane.showMessageDialog(null, "Player 2 already introduced himself");
                }
            }

        });
        //Show hand p2
        p2Btn2.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                if (checkShowHandP2 == 0) {
                    if (dealToPlayers == 1) {

                        checkShowHandP2 = 1;

                        int score2 = 0;
                        for (int i = 0; i < 5; i++) {
                            if (P2.hand[i].toString().contains("#")) {
                                score2++;
                            }
                        }

                        mainta.setText(P2.username + " : I have " + score2 + " heart(s)!!");
                        p2Hearts.setText("Number of hearts : " + score2);

                        for (int i = 0; i < 5; i++) {

                            String pathShowP2 = P2.hand[i] + ".png";
                            ImageIcon showCardP2 = new ImageIcon("Images/" + pathShowP2);

                            JLabel p2ShowLabel = new JLabel(showCardP2);
                            p2Hand.remove(i);
                            p2Hand.add(p2ShowLabel, i);
                            p2Hand.repaint();
                            p2Hand.revalidate();
                        }
                        
                    } else {
                        JOptionPane.showMessageDialog(null, "Deal to players first!!");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "This player have already shown his hand");
                }
            }

        });

        //dealer introduce
        dBtn1.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                if (introduceD == 0) {
                    introduceD = 1;
                    String txtArea = dealer.IntroduceYourSelf();

                    dealerLabel.setText("                              " + dealer.Fname + " " + dealer.Lname);

                    mainta.setText(txtArea);
                } else {
                    JOptionPane.showMessageDialog(null, "Dealer already introduced himself");
                }
            }

        });

        //dealer show deck
        dBtn2.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {

                if (introduceP1 == 1 && introduceP2 == 1 && introduceD == 1) {
                    if (checkShowDeck == 0) {
                        checkShowDeck = 1;

                        if (round >= 2) {
                            String pathEmpty = "empty.png";

                            ImageIcon empty = new ImageIcon("Images/" + pathEmpty);

                            JLabel p1EmptyLabel0 = new JLabel(empty);
                            JLabel p1EmptyLabel1 = new JLabel(empty);
                            JLabel p1EmptyLabel2 = new JLabel(empty);
                            JLabel p1EmptyLabel3 = new JLabel(empty);
                            JLabel p1EmptyLabel4 = new JLabel(empty);

                            JLabel p2EmptyLabel0 = new JLabel(empty);
                            JLabel p2EmptyLabel1 = new JLabel(empty);
                            JLabel p2EmptyLabel2 = new JLabel(empty);
                            JLabel p2EmptyLabel3 = new JLabel(empty);
                            JLabel p2EmptyLabel4 = new JLabel(empty);

                            p1Hand.remove(0);
                            p1Hand.add(p1EmptyLabel0, 0);
                            p1Hand.repaint();
                            p1Hand.revalidate();

                            p1Hand.remove(1);
                            p1Hand.add(p1EmptyLabel1, 1);
                            p1Hand.repaint();
                            p1Hand.revalidate();

                            p1Hand.remove(2);
                            p1Hand.add(p1EmptyLabel2, 2);
                            p1Hand.repaint();
                            p1Hand.revalidate();

                            p1Hand.remove(3);
                            p1Hand.add(p1EmptyLabel3, 3);
                            p1Hand.repaint();
                            p1Hand.revalidate();

                            p1Hand.remove(4);
                            p1Hand.add(p1EmptyLabel4, 4);
                            p1Hand.repaint();
                            p1Hand.revalidate();

                            p2Hand.remove(0);
                            p2Hand.add(p2EmptyLabel0, 0);
                            p2Hand.repaint();
                            p2Hand.revalidate();

                            p2Hand.remove(1);
                            p2Hand.add(p2EmptyLabel1, 1);
                            p2Hand.repaint();
                            p2Hand.revalidate();

                            p2Hand.remove(2);
                            p2Hand.add(p2EmptyLabel2, 2);
                            p2Hand.repaint();
                            p2Hand.revalidate();

                            p2Hand.remove(3);
                            p2Hand.add(p2EmptyLabel3, 3);
                            p2Hand.repaint();
                            p2Hand.revalidate();

                            p2Hand.remove(4);
                            p2Hand.add(p2EmptyLabel4, 4);
                            p2Hand.repaint();
                            p2Hand.revalidate();

                        }

                        mainta.setText(dealer.Fname + " : Here is the deck");

                        JLabel[] labels = new JLabel[52];

                        for (int i = 0; i < dealer.newDeck.cards.size(); i++) {

                            String pathCard = dealer.newDeck.cards.get(i) + ".png";
                            ImageIcon card = new ImageIcon("Images/" + pathCard);
                            labels[i] = new JLabel(card);
                            deck.add(labels[i]);
                            deck.revalidate();
                            deck.repaint();
                        }
                        mainta.setSize(730, 100);

                    } else {
                        JOptionPane.showMessageDialog(null, "I have already shown the deck");

                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Everyone has to introduce first");
                }

            }

        });

        //deal to players
        dBtn3.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                if (checkShowDeck == 1) {
                    if (dealToPlayers == 0) {
                        dealToPlayers = 1;

                        checkDecideWinner = 0;//oste na mporei na xanadixei pios ine o winner

                        mainta.setText(dealer.Fname + " : I dealt 5 cards to each player. Please reveal your cards!!");
                        p1Hearts.setText("Number of hearts : ");
                        p2Hearts.setText("Number of hearts : ");

                        deck.removeAll();
                        deck.repaint();
                        deck.revalidate();

                        dealer.shuffleDeck();
                        dealer.dealToPlayers(P1, P2);

                        String pathBack = "backview.png";

                        ImageIcon back = new ImageIcon("Images/" + pathBack);

                        JLabel p1BackLabel0 = new JLabel(back);
                        JLabel p1BackLabel1 = new JLabel(back);
                        JLabel p1BackLabel2 = new JLabel(back);
                        JLabel p1BackLabel3 = new JLabel(back);
                        JLabel p1BackLabel4 = new JLabel(back);

                        JLabel p2BackLabel0 = new JLabel(back);
                        JLabel p2BackLabel1 = new JLabel(back);
                        JLabel p2BackLabel2 = new JLabel(back);
                        JLabel p2BackLabel3 = new JLabel(back);
                        JLabel p2BackLabel4 = new JLabel(back);

                        p1Hand.remove(0);
                        p1Hand.add(p1BackLabel0, 0);
                        p1Hand.repaint();
                        p1Hand.revalidate();

                        p1Hand.remove(1);
                        p1Hand.add(p1BackLabel1, 1);
                        p1Hand.repaint();
                        p1Hand.revalidate();

                        p1Hand.remove(2);
                        p1Hand.add(p1BackLabel2, 2);
                        p1Hand.repaint();
                        p1Hand.revalidate();

                        p1Hand.remove(3);
                        p1Hand.add(p1BackLabel3, 3);
                        p1Hand.repaint();
                        p1Hand.revalidate();

                        p1Hand.remove(4);
                        p1Hand.add(p1BackLabel4, 4);
                        p1Hand.repaint();
                        p1Hand.revalidate();

                        p2Hand.remove(0);
                        p2Hand.add(p2BackLabel0, 0);
                        p2Hand.repaint();
                        p2Hand.revalidate();

                        p2Hand.remove(1);
                        p2Hand.add(p2BackLabel1, 1);
                        p2Hand.repaint();
                        p2Hand.revalidate();

                        p2Hand.remove(2);
                        p2Hand.add(p2BackLabel2, 2);
                        p2Hand.repaint();
                        p2Hand.revalidate();

                        p2Hand.remove(3);
                        p2Hand.add(p2BackLabel3, 3);
                        p2Hand.repaint();
                        p2Hand.revalidate();

                        p2Hand.remove(4);
                        p2Hand.add(p2BackLabel4, 4);
                        p2Hand.repaint();
                        p2Hand.revalidate();
                    } else {
                        JOptionPane.showMessageDialog(null, "You have already dealt to the players!");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Show deck first!!");
                }
            }

        });

        //decide winner
        dBtn4.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                if (checkDecideWinner == 0) {
                    if (checkShowHandP1 == 1 && checkShowHandP2 == 1) {

                        checkDecideWinner = 1;//oste na mn borei na xanadixei pios ine o winner ston idio giro
                        String txtArea = dealer.decideWinner(P1, P2, round);

                        mainta.setText(txtArea);
                        p1Score.setText("Total Points : " + P1.points);
                        p2Score.setText("Total Points : " + P2.points);

                        if (round < 5) {
                            round++;
                            checkShowHandP1 = 0;
                            checkShowHandP2 = 0;
                            dealToPlayers = 0;

                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "I cannot decide who the winner is yet");
                    }

                } else {
                    JOptionPane.showMessageDialog(null, "I have already shown who the winner is");
                }
            }

        });

    }

}
