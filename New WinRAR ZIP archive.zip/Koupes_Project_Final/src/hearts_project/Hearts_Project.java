package hearts_project;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Hearts_Project {
    
    static Connection conn = null;
    ResultSet rs = null;
    PreparedStatement pst = null;
   
    public static void main(String[] args) {
      
      Heartsdealer dealer = new Heartsdealer();
      HeartPlayer P1 = new HeartPlayer();
      HeartPlayer P2 = new HeartPlayer();
      
      
      new Register(dealer,P1,P2);
      
        
    }
    
}
