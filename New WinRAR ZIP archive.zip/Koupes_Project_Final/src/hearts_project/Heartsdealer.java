package hearts_project;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collections;
import java.util.Random;
import static hearts_project.Hearts_Project.conn;

public class Heartsdealer extends Human implements CardDealer {
    
    
    
    ResultSet rs;
    Statement stmt;
    
    String txtArea;

    public Heartsdealer() {

        super();

    }
    
    Deck newDeck = new Deck();

   


    @Override
    public void shuffleDeck() {
        long seed = System.nanoTime();
        Collections.shuffle(newDeck.cards, new Random(seed));
    }

    @Override
    public void dealToPlayers(HeartPlayer player1, HeartPlayer player2) {
        int j = 0;

        for (int i = 0; i < 5; i++) {

            player1.hand[i] = newDeck.cards.get(j);
            player2.hand[i] = newDeck.cards.get(++j);
            j++;
        }
    }

    @Override
    public String decideWinner(HeartPlayer player1, HeartPlayer player2, int round) {

        int score1 = 0;
        int score2 = 0;
        for (int i = 0; i < 5; i++) {
            if (player1.hand[i].toString().contains("#")) {
                score1++;
            }
            if (player2.hand[i].toString().contains("#")) {
                score2++;
            }
        }
        System.out.println();

       
        //conn = SQLConnection.ConnectDB();
        
       

        if (score1 > score2) {
            
            player1.points += (score1 * 10 - score2 * 10);
            txtArea = ("The winner of round "+round+" is " + player1.username+" with "+score1+" hearts."
                    + "\n He wins "+(score1 * 10 - score2 * 10)+" points");
            /*
            try {
                stmt = conn.createStatement();
                int sql = stmt.executeUpdate("INSERT INTO game VALUES ('"+player1.username+"','"+player1.points+"','"+player2.points+"')");
            } catch (SQLException e) {
                System.out.println("Error inserting values 1");
                //an exei perisoteres koupes o P1 tote vazo to username sto winner kai tou dino 10 pontous gia ka8e koupa pou exei parapano apton P2  
                //vazo round+1 oste tin epomeni fora pou 8a kano select ta round na einai +1 ara i metavliti round sto epomeno treximo tou kodika 8a einai +1
            }*/
            
        } else if (score2 > score1) {
            txtArea = ("The winner of round "+round+ " is " + player2.username+" with "+score2+" hearts"
                    + "\n He wins "+(score2 * 10 - score1 * 10)+" points");
            player2.points += (score2 * 10 - score1 * 10);
            /*
            try {
                stmt = conn.createStatement();
                int sql = stmt.executeUpdate("INSERT INTO game VALUES ('"+player2.username+"','"+player1.points+"','"+player2.points+"')");
            } catch (SQLException e) {
                System.out.println("Error inserting values 2");
                //an exei perisoteres koupes o P2 tote vazo to username sto winner kai tou dino 10 pontous gia ka8e koupa pou exei parapano apton P1
                
            } */  
        } else {
            txtArea = ("Round "+round+ " ends with a tie! Both players had " + score1 + " hearts!!"
                    + "\nNoone wins points.");
            /*
            try {
                stmt = conn.createStatement();
                int sql = stmt.executeUpdate("INSERT INTO game VALUES ('"+"TIE"+"','"+player1.points+"','"+player2.points+"')");
            } catch (SQLException e) {
                System.out.println("Error inserting values 3");
                //an exoun idies koupes leo oti einai isopalia kai apla kano insert ta proigoumena stixia pros8etontas omos 1 sta rounds
            }*/
        }
        if(round>=5){
            //an isxuei simenei oti molis teliose to 5o pexnidi kai prepei na vgaloume ton teliko nikiti
            
            
             //getting current date and time
            DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
            Calendar cal = Calendar.getInstance();
            String date = dateFormat.format(cal.getTime());
            
            
            
            if(player1.points>player2.points){
                txtArea = (player1.username+" WON THE GAME WITH "+ player1.points+" POINTS!!! "
                        + "\nTHE GAME IS OVER." );
                
                /*
                 try {
              
                    stmt = conn.createStatement();
                    int sql = stmt.executeUpdate("INSERT INTO prevgames VALUES ('" + player1.username + "','" + date +"','" + player1.points +"','" + player2.points +"')");
                    conn.close();
                   
            }
          catch (SQLException ex) {
                    System.out.println("Error inserting values");
                }
                */
                
                
                
            }else if(player2.points>player1.points){
                
                /*
                   try {
              
                    stmt = conn.createStatement();
                    int sql = stmt.executeUpdate("INSERT INTO prevgames VALUES ('" + player2.username + "','" + date +"','" + player1.points +"','" + player2.points +"')");
                    conn.close();
                   
            }
          catch (SQLException ex) {
                    System.out.println("Error inserting values");
                }
                */
                
                
                txtArea = (player2.username+" WON THE GAME WITH "+ player2.points+" POINTS!!!"
                        + "\nTHE GAME IS OVER." );
            }else{
                
                
             /*      try {
              
                    stmt = conn.createStatement();
                    int sql = stmt.executeUpdate("INSERT INTO prevgames VALUES ('"+ "TIE" +"','" + date +"','" + player1.points +"','" + player2.points +"')");
                    conn.close();
                   
            }
          catch (SQLException ex) {
                    System.out.println("Error inserting values");
                }
               */ 
                
                 txtArea = ("GAME ENDED WITH A TIE. BOTH PLAYERS HAD "+player1.points+" POINTS!!"
                         + "\nTHE GAME IS OVER.");
            }
            
  

        }
        return txtArea;
    }

    @Override
    public String IntroduceYourSelf() {


        String txt=("Hello, my name is " + Fname + " " + Lname + " and i am the dealer"
                        + ". I am " + age + " years old.");
        return txt;
        
    }

}
